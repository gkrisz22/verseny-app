EXPLAIN PLAN SET statement_id='ut1'  -- 'ut1' -> az utasítás egyedi neve
   FOR 
   SELECT dname, job, AVG(sal) FROM nikovits.emp NATURAL JOIN nikovits.dept
   WHERE hiredate > to_date('1981.01.01', 'yyyy.mm.dd')
   GROUP BY dname, job HAVING SUM(sal) > 5000
   ORDER BY AVG(sal) DESC;

select plan_table_output from table(dbms_xplan.display('plan_table','ut1','all'));

EXPLAIN PLAN SET statement_id='ut2'  
   FOR
    select /*+ index(osztaly) */ onev from osztaly 
    where oazon in
    (select d.oazon from dolgozo d, fiz_kategoria f
    where d.fizetes between f.also and f.felso 
    and f.kategoria = 1)
    
create unique index unique_onev_idx on osztaly(onev);

create index dolgozo_fizetes_idx on dolgozo(fizetes);

create unique index unique_fizkat_idx on fiz_kategoria(kategoria);


EXPLAIN PLAN SET statement_id='ut3'  
   FOR
SELECT sum(darab) FROM nikovits.hivas, nikovits.kozpont, nikovits.primer
WHERE hivas.kozp_azon_hivo=kozpont.kozp_azon AND kozpont.primer=primer.korzet
AND primer.varos = 'Szentendre' 
AND datum + 1 = next_day(to_date('2012.01.31', 'yyyy.mm.dd'),'hétfő');

EXPLAIN PLAN SET statement_id='ut4'  
   FOR
SELECT sum(darab) FROM nikovits.hivas, nikovits.kozpont, nikovits.primer
WHERE hivas.kozp_azon_hivo=kozpont.kozp_azon AND kozpont.primer=primer.korzet
AND primer.varos = 'Szentendre' 
AND datum = next_day(to_date('2012.01.31', 'yyyy.mm.dd'),'hétfő') - 1;

select * from dba_part_tables
where owner = 'NIKOVITS' and table_name = 'HIVAS';

select * from dba_tab_partitions
where table_name = 'HIVAS';

select * from dba_part_key_columns
where name = 'HIVAS';

select * from dba_indexes
where owner = 'NIKOVITS' 
and (table_name='SZALLIT' or table_name = 'CIKK');

select * from dba_ind_columns
where table_owner = 'NIKOVITS' 
and (table_name='SZALLIT' or table_name = 'CIKK');

-- a
EXPLAIN PLAN SET statement_id='ut5'  
   FOR
select /*+ NO_INDEX(sz, c) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut5','all'));

-- b
EXPLAIN PLAN SET statement_id='ut6'  
   FOR
select /*+ INDEX(c) NO_INDEX(sz) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut6','all'));

EXPLAIN PLAN SET statement_id='ut7'  
   FOR
select /*+ NO_INDEX(c) INDEX(sz) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut7','all'));

-- c

EXPLAIN PLAN SET statement_id='ut8' 
   FOR
select /*+ INDEX(sz) INDEX(c) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut8','all'));

-- d


EXPLAIN PLAN SET statement_id='ut9'  
   FOR
select /*+ USE_MERGE(sz, c) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut9','all'));

-- e

EXPLAIN PLAN SET statement_id='ut10'  
   FOR
select /*+ USE_NL(sz, c) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut10','all'));

-- f

EXPLAIN PLAN SET statement_id='ut11'  
   FOR
select /*+ USE_HASH(sz, c) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut11','all'));

-- g

EXPLAIN PLAN SET statement_id='ut12' 
   FOR
select /*+ USE_NL(sz, c) NO_INDEX(sz) NO_INDEX(c) */ sum(mennyiseg) 
from nikovits.szallit sz JOIN nikovits.cikk c
on sz.ckod = c.ckod
where szin = 'piros'

select plan_table_output from table(dbms_xplan.display('plan_table','ut12','all'));