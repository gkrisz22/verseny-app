-- 1
explain plan set STATEMENT_ID = 'ut0801'
for
select sum(mennyiseg)
from nikovits.szallit
where ckod = 2 and szkod = 2;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0801', 'all'));

-- a
explain plan set STATEMENT_ID = 'ut0801a'
for
select /*+ NO_INDEX(sz) */ sum(mennyiseg)
from nikovits.szallit sz
where ckod = 2 and szkod = 2;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0801a', 'all'));

-- b
explain plan set STATEMENT_ID = 'ut0801b'
for
select /*+ AND_EQUAL(sz szt_ckod szt_szkod) */ sum(mennyiseg)
from nikovits.szallit sz
where ckod = 2 and szkod = 2;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0801b', 'all'));

-- 2
explain plan set statement_id = 'ut0802a'
for
select /*+ LEADING(sz c) */ sum(mennyiseg)
from nikovits.szallit sz 
    natural join nikovits.szallito szo 
    natural join nikovits.cikk c
where szo.telephely = 'Pecs' and c.szin = 'piros';

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0802a', 'all'));


explain plan set statement_id = 'ut0802b'
for
select /*+ ORDERED */ sum(mennyiseg)
from nikovits.szallit sz 
    natural join nikovits.szallito szo 
    natural join nikovits.cikk c
where szo.telephely = 'Pecs' and c.szin = 'piros';

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0802b', 'all'));

-- 3
explain plan set STATEMENT_ID = 'ut0803'
for
select sum(mennyiseg)
from nikovits.szallit
where ckod = 1 or szkod = 2;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0803', 'all'));

-- a
explain plan set STATEMENT_ID = 'ut0803a'
for
select /*+ NO_INDEX(sz) */ sum(mennyiseg)
from nikovits.szallit sz
where ckod = 1 or szkod = 2;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0803a', 'all'));

-- b
explain plan set STATEMENT_ID = 'ut0803b'
for
select /*+ USE_CONCAT */ sum(mennyiseg)
from nikovits.szallit sz
where ckod = 1 or szkod = 2;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0803b', 'all'));

-- 4
explain plan set STATEMENT_ID = 'ut0804a'
for
select count(*)
from nikovits.cikk;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804a', 'all'));


explain plan set STATEMENT_ID = 'ut0804b'
for
select sum(suly)
from nikovits.cikk
where ckod = 100;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804b', 'all'));


explain plan set STATEMENT_ID = 'ut0804c'
for
select /*+ USE_HASH(sz p) NO_INDEX(sz) NO_INDEX(p) */ count(*)
from nikovits.szallit sz natural join nikovits.projekt p;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804c', 'all'));



explain plan set STATEMENT_ID = 'ut0804d'
for
select /*+ USE_HASH(sz p) NO_INDEX(sz) NO_INDEX(p) */ pkod, count(*)
from nikovits.szallit sz natural join nikovits.projekt p
group by pkod;

select * from nikovits.projekt;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804d', 'all'));


explain plan set STATEMENT_ID = 'ut0804e'
for
select /*+ USE_MERGE(sz c) NO_INDEX(sz) INDEX(c c_szin) */ count(*)
from nikovits.szallit sz natural join nikovits.cikk c
where c.szin = 'piros';

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804e', 'all'));


explain plan set STATEMENT_ID = 'ut0804f'
for
select /*+ full(sz) */ sum(mennyiseg)
from nikovits.szallit sz, nikovits.szallito szto, nikovits.projekt p
where sz.pkod=p.pkod and sz.szkod=szto.szkod and szto.szkod=15
and helyszin='Szeged' and telephely='Pecs';

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804f', 'all'));



explain plan set STATEMENT_ID = 'ut0804g'
for
select /*+ full(sz) */ sum(mennyiseg), ckod
from nikovits.szallit sz, nikovits.szallito szto, nikovits.projekt p
where sz.pkod=p.pkod and sz.szkod=szto.szkod and szto.szkod=15
and helyszin='Szeged' and telephely='Pecs'
group by ckod having ckod>100;

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804g', 'all'));


explain plan set STATEMENT_ID = 'ut0804h'
for
select /*+ leading(sz) */ sum(mennyiseg)
from nikovits.szallit sz
where ckod not in
  (select /*+ hash_sj */ ckod from nikovits.cikk c 
  where szin='piros');

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804h', 'all'))


explain plan set STATEMENT_ID = 'ut0804i'
for
select /*+ leading(sz) */ sum(mennyiseg)
from nikovits.szallit sz
where exists
  (select /*+ hash_sj */ ckod from nikovits.cikk c 
  where c.ckod=sz.ckod and szin='piros');

select plan_table_output 
from table(dbms_xplan.display('plan_table', 'ut0804i', 'all'))


-- 4
create table product_tmp as select * from nikovits.product

create bitmap index product_color_idx on product_tmp(color)
create bitmap index product_weight_idx on product_tmp(weight)

explain plan set statement_id = 'st0804' for
select /*+ INDEX(p product_color_idx product_weight_idx) */* from product_tmp p
where color = 'red' and weight > 10

select * from plan_table where statement_id = 'st0804'